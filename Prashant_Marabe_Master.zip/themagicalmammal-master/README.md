<p><img src="https://i.imgur.com/Fihbexl.gif" alt="Hello" width="250" /></p>
<p>
	<codersrank-skills-chart username="prashantmarbe"></codersrank-skills-chart> Hey, I am Prashant Marabe, Working as a Front-end developer &#39;I was born in <img src="https://i.imgur.com/DzzzpBo.png" width="13" /> <b>Bengaluru, India</b>. </p>
<h3><img src="https://i.imgur.com/HFHIBmx.png" width="18" /> Pics from <img src="https://i.imgur.com/DPngeUJ.png" width="13" /> Leeds</h3>
<p><img width="200" src="https:&#x2F;&#x2F;cdn3.dumpor.com&#x2F;view?q&#x3D;%3D%3DwIx8zZlBnau0TPnJkaJVkM5pWZLVzK3RzSyYlM4VjcPNGOxhnTvpkVnpWYKRlbCZVe6NWT3hDMaFjTyZUOullYoJmb6tCf8RnQwdEdkBFUxhzaBZXZtJDT0E0VWt2QkhWN11GVapkZ5p3QDF2cSJFM5ITUHVlQORVQBJDf8N3NwwHfu1EehZERlZjbrkDN0E0aqxWbqZFai92ZMBXMJN2U5l3dadHeZ5EU6dGMwcTd0x0NsNEU6hEeGZUZrlUMWVHWulne1ZnNHdmZpN0ZJFkaSZTc2E0cOpnY2dVR0REcjBlS4wGc4xkd4cUOFFEVKpWTvZDeqxmaPtid58GNhl3NxAHSwYnW0QEND12SSJmTSpXMvdUTyEUN1J3bLhTY3gnY8xHSF9WZRZWSU1UWqp3TxN2Y5YnNYplY3NDT5hDTrdmWwlDaORUMrN0bWFmNxVDZkpHVCJDTRhlewAVeGZkWYxGbWF3ZvRTa5onZMtyUIlDa3tkNoREf852RkdHdshTNCdFSiNXS45Uaalnbwo2NTF2Y15kU1EES2VEUykUOM12V14EZJhERadkQq5WWOVnTohXZw0Tcv0WYydWY0Nnbp1Sei1CZlR3cvh2Lt92YuIXao1WYydmLx4GZj9yL6MHc0RHa" /> <img width="200" src="https:&#x2F;&#x2F;cdn1.dumpor.com&#x2F;view?q&#x3D;%3DMSM%2FcWZwpmL9MmaWd2YoJzcy80YwcFe6JzQGZTSrRHVXRTc3x0caVlcExHfMFmNXlFV8xXYORTRsNWO5oEVPZWNPJDWp1GeuNGWJ1Gf8hUSzQTOs9WYR1mM3ITZqZUMIlkUrQ0SFZGT2NjeKd1NytSUrtiaOd1RTRXeHt0SxN3Nnx0KNhXYGF0SKJDdwkzZlNma2IzRGhWW1clSwBndZlVbsJzb0hmZBBFentUSltmYMZTNjlGRHJUMXRmVzlXUvRlb4ZzNPZjNR1Ea6VkdVlXO2YjNwNWT5xkdFxUUEJXVrQzN3o0aLxGMHZHS4pmTyUFN8xnMYVVahJmc2YWSKh3SS90Q4AlS0skWHt2QWdDZ5IGVwFFbx8UdHFWNUhWcr8Wd3cERZF2RJd2UklVb3VlczNHOwtyMalVSYp0M3J3aoJlW54WMUFjTuVXVkVnN2MlWUJlSLxEVkhEMPxHfOZkWUxmVWVHOvRzbapmZMtyUIlDa3tkNoREf852RkdHdshTNCdFSiNXS45Uaalnbwo2NTF2Y15kU1EES2VEUykUOM12V14EZJhERadkQq5WWOVnTohXZw0Tcv0WYydWY0Nnbp1Sei1CZlR3cvh2Lt92YuIXao1WYydmLx4GZj9yL6MHc0RHa" /> <img width="200" src="https:&#x2F;&#x2F;cdn3.dumpor.com&#x2F;view?q&#x3D;jEzPnVGcq5SP3ZFamdndHhVW0tWU050TxUHf8hUYyMjQDdlNVRGb5NkU0czRZF2SThlM3xHfFpHUZZjMOxUWI1UarkVYmZ2V3oHc3cVMlRmb55UayYWauR1aIdFNz1WOC1WS0dVVSNWVBpGSvp2b1sEasp0bjNja4Mje1k1c5FEbsF2UI9GOzFjZ0cmdkl0QrBXMFR1Y1VGRpFFcP1WWPdTbRdFeHp3cUFGNvh0UxJ2Z4RnZPVjNR1Ea6VkdI5WQQtyZ5MWTQZmdVFzduZnZQ50NtBDMKpGMHZHTOpWS8xnV0BnMDtmaEN1SyRXQKJTeOtEVzITT1BVSDdHdjVXY5gVevdUTyEUN1J3bLhTY3gnY8xHSF9WZRZWSU1UWqp3T1F0c582QIJWWFNDT5NncspGZ1kzakpmMoNUSYFVaLdzY4pGVCl3NTd1MwAlekZkWZFjVWpWTvVzbapmZMtyUIlDa3tkNoREf852RkdHdshTNCdFSiNXS45Uaalnbwo2NTF2Yl5kU1EES2VEUykUOM12V14EZJhERadkQq5WWOVnTohXZw0Tcv0WYydWY0Nnbp1Sei1CZlR3cvh2Lt92YuIXao1WYydmLx4GZj9yL6MHc0RHa" /></p>
<p> Above are the last 3 pictures posted by
	<a href="https://www.instagram.com/visitleeds/" target="_blank"> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/1024px-Instagram_logo_2016.svg.png" width="13" /> @visitleeds!</a>
	<br /> Currently, the weather is: <b> 7°C, <i>fog</i></b>
	<br /> Today, the sun rises at <b>05:09</b> and sets at <b>18:19</b>. </p>
<h3><img src="https://i.imgur.com/aSVPWXc.png" width="18" /> Spotify Playing</h3>
<a href="https://open.spotify.com/user/88h9x52o4rver6y7ka9upj5a6"><img src="https://spotify-pw0mefqpu-spotifydipan.vercel.app/api/spotify" alt="Spotify" /></a>
<h3><img src="https://i.imgur.com/84QPnNl.png" width="18" /> My Stats</h3> <img src="https://github-readme-stats-bay-ten-48.vercel.app/api?username=themagicalmammal&amp;include_all_commits=true&amp;bg_color=30,e96443,904e95&amp;title_color=fff&amp;text_color=fff" alt="Dipan&#39;s GitHub stats" />
<h3><img src="https://i.imgur.com/yQHTmCW.png" width="18" /> Where to find me</h3>
<a href="https://github.com/themagicalmammal/"> <img alt="Github" width="40px" src="https://i.imgur.com/RjscN2M.png" /></a>
<a href="https://uk.linkedin.com/in/themagicalmammal/"> <img alt="Linkedin" width="40px" src="https://i.imgur.com/Hp2w5wM.png" /></a>
<a href="https://www.reddit.com/user/themagicalmammal/"> <img alt="Reddit" width="40px" src="https://i.imgur.com/E8vTLyb.png" /></a>
<a href="https://telegram.im/@themagicalmammal"> <img alt="Telegram" width="40px" src="https://i.imgur.com/8uCq4fi.png" /> </a>
<a href="https://dsc.bio/themagicalmammal"> <img alt="Discord" width="40px" src="https://i.imgur.com/allk32s.png" /></a>
<a href="https://forum.xda-developers.com/m/themagicalmammal.9670192/"> <img alt="XDA" width="40px" src="https://i.imgur.com/ZkDQREa.png" /></a>
<a href="https://open.spotify.com/user/88h9x52o4rver6y7ka9upj5a6?si=i5kyqZQOQmOu_NRn-T7FQw&nd=1"> <img alt="Spotify" width="40px" src="https://i.imgur.com/TuGJlcZ.png" /> </a>
<a href="https://gist.github.com/themagicalmammal/"> <img alt="Gist" width="40px" src="https://i.imgur.com/6w4HNmL.png" /></a>
<a href="https://www.sololearn.com/profile/4562055"> <img alt="Sololearn" width="40px" src="https://i.imgur.com/6mnh2V5.png" /></a>
<a href="https://www.deviantart.com/themagicalmammal"> <img alt="Devintart" width="40px" src="https://i.imgur.com/YWUKoPE.png" /></a>
<a href="https://pypi.org/user/themagicalmammal/"> <img alt="Pypi" width="40px" src="https://i.imgur.com/901ps8h.png" /></a>
<a href="https://myanimelist.net/profile/themagicalmammal"> <img alt="MAL" width="40px" src="https://i.imgur.com/TnZcuA4.png" /></a>
<a href="https://medium.com/@d19cyber"> <img alt="Medium" width="40px" src="https://i.imgur.com/HvRIk6L.png" /></a>
<a href="https://secure.plum.io/p/2Ui2Qr0KSS7QP04pEq_-BQ"> <img alt="Plum" width="40px" src="https://i.imgur.com/PNhxaKM.png" /></a>
<br />
<br />
<details>
	<summary> &#9655;</summary>
	<h3><img src="https://i.imgur.com/x8tsLuE.png" width="18" /> Trophies</h3> <img src="https://github-profile-trophy.vercel.app/?username=themagicalmammal&amp;theme=juicyfresh&amp;row=1&amp;column=5" alt="trophy" />
	<br />
	<br />
	<details>
		<summary> &#9655;</summary>
		<h3><img src="https://i.imgur.com/xGG5c7N.png" width="18" /> QR Code</h3> <img alt="QRCode" width="200px" src="https://i.imgur.com/DSHPHdq.png" />
		<details>
			<summary> &#9655;</summary>
			<h3><img src="https://i.imgur.com/1mimHIo.png" width="18" /> Credits</h3>
			<ol>
				<li><img src="https://cdn-icons-png.flaticon.com/128/197/197484.png" width="13" /> <a href="https://github.com/sourajitk">Sourajit Karmakar</a></li>
				<li><img src="https://cdn-icons-png.flaticon.com/128/197/197564.png" width="13" /> <a href="https://github.com/thmsgbrt">Thomas Guibert</a></li>
				<li><img src="https://cdn-icons-png.flaticon.com/512/3909/3909444.png" width="13" /> <a href="https://github.com/Prince-Shivaram">Siv Ram Shastri Jonnalagadda</a></li>
				<li><img src="https://cdn-icons-png.flaticon.com/512/3909/3909444.png" width="13" /> <a href="https://github.com/anuraghazra">Anurag Hazra</a></li>
				<li><img src="https://cdn-icons-png.flaticon.com/128/197/197559.png" width="13" /> <a href="https://github.com/owl4ce">Harry</a></li>
				<li><img src="https://cdn-icons-png.flaticon.com/128/197/197484.png" width="13" /> <a href="https://github.com/ryanlanciaux">Ryan Lanciaux</a></li>
			</ol>
			<details>
				<summary> &#9655;</summary>
				<h3><img src="https://i.imgur.com/XJ0hI8P.png" width="18" /> Visitor</h3> <img src="https://profile-counter.glitch.me/themagicalmammal/count.svg" />
				<br /> </details>
		</details>
	</details>
</details>
<br />
<p><img src="https://i.imgur.com/JgaEjcz.png" width="13" /> <b>Last refresh:</b> Monday, 12 September, 02:03 BST</p>
